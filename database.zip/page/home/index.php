<section class="hero is-medium is-primary is-bold">
    <div class="hero-body">
        <div class="container">
            <h1 class="title animate__animated animate__zoomIn">
                SPK PENILAIAN GURU HONORER MENGGUNAKAN METODE WEIGHTED PRODUCT (WP)
            </h1>
            <h2 class="subtitle animate__animated animate__slideInUp">
                SMK Negeri 1 Jambi
            </h2>
        </div>
    </div>
</section>