<?php
require("../controller/Kriteria.php");

$id = $_GET['id'];
$koneksi = Koneksi();

// Cek apakah kriteria masih digunakan di tabel penilaian
$check = mysqli_query($koneksi, "SELECT * FROM penilaian WHERE id_kriteria = $id");

if (mysqli_num_rows($check) > 0) {
    // Jika masih digunakan, tampilkan alert
    echo "<script>
        Swal.fire({
            icon: 'warning',
            title: 'Tidak Bisa Dihapus',
            text: 'Data tidak dapat dihapus karena masih digunakan dalam tabel penilaian. Silakan hapus penilaian terlebih dahulu.',
            showClass: {
                popup: 'animate__animated animate__fadeInDown'
            },
            hideClass: {
                popup: 'animate__animated animate__fadeOutUp'
            }
        }).then(function() {
            window.location.href = 'index.php?halaman=datakriteria';
        });
    </script>";
} else {
    // Lanjut hapus jika tidak digunakan
    if (Delete("kriteria", "id_kriteria", $id) > 0) {
        echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil',
                text: 'Data berhasil dihapus',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            }).then(function() {
                window.location.href = 'index.php?halaman=datakriteria';
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Gagal',
                text: 'Data gagal dihapus',
                showClass: {
                    popup: 'animate__animated animate__fadeInDown'
                },
                hideClass: {
                    popup: 'animate__animated animate__fadeOutUp'
                }
            }).then(function() {
                window.location.href = 'index.php?halaman=datakriteria';
            });
        </script>";
    }
}
